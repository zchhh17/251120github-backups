


def quote_url(url):
    return url.replace('{','%7B').replace('}','%7D')