# Snippets
来自佬王大佬原始代码二开修改的，支持所有客户端自定义落地IP
#
✅ 改完后你可以这样用：
#
✅方案一:v2客户保持原始方法
#
✅方案二：其他客户端,把你的代理ip改成64编码
#
转化网址：https://scosk5.ssr.baby
```bash
示例路径：/c29ja3M1Oi8vV1k0azY1OTk0OmVQMkVQUHdoQDIwMi4xNjfdgsd2OjQ0Mw
```
✅其他（可选）方案
#
例如小火箭，可以选择在ws路径里面右上角+添加新的请求头！
#
头字段
```bash
X-ProxyIP
```
值
```bash
socks5://用户名:密码@IP:端口
```
