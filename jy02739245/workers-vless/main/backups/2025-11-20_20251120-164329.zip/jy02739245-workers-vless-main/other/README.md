> ip-query.js是部署在Cloudflare  workers 用于查询ip的工具，从多个api查询，用于参考，复制到workers直接部署即可。
<img width="2328" height="1242" alt="image" src="https://github.com/user-attachments/assets/bfb23acc-cd85-41fc-8cb4-cf4dbef74eb9" />

> ip-query-gemini.js与ip-query.js功能一样的，只是用gemini改了显示UI，更好看一些，对移动设备兼容好。
<img width="2654" height="1326" alt="image" src="https://github.com/user-attachments/assets/dfc67843-e3c7-4b72-b2cc-8dc443ede7f0" />


