# Workers-snippets

根据mingyu的snippets版本结合天书大佬的控流用AI改的，控流从6m开始提升，无上限

* 群聊: [HeroCore](https://t.me/HeroCore)
* 频道: [HeroMsg](https://t.me/HeroMsg)


  * `/s=admin:123456@123.123.28.123:13333`（仅SOCKS5）
  * `/g=admin:123456@123.123.28.123:13333`（全局SOCKS5）
  * `/p=ProxyIP.US.CMLiussss.net`（仅Proxyip）
  * `/h=192.168.1.1:1080`（回退http）
  * `/gh=192.168.1.1:1080`（全局http）
