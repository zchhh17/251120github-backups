全自动优选CF的IP，包含美国US，日本JP，新加坡SG，德国DE，荷兰NL等cloudflare每天每小时自动优选IP，自动生成CF免费Vless节点。

<b>手搓CF节点极简版</b>：<a href=https://github.com/gslege/CloudflareIP/blob/main/CF-Worker/_worker.js>_worker.js</a>，推荐使用Pages部署，无需自定义域名而且稳定，默认UUID：04c808e2-0b59-47b0-a54b-32fc7ef1c902 建议部署时修改，然后用<b><a href=https://sub.cndyw.ggff.net>手搓CF节点生成器</a></b>生成节点导入到v2ray或karing中使用。

复刻本仓库然后部署到cloudflare上，即可生成自己的节点生成器页面！

<b>手搓CF节点生成器：https://sub.cndyw.ggff.net</b> 或 <b>https://ip.gslege.ggff.net</b> 

<b>免费自适应节点a</b>：https://suba.cndyw.ggff.net/suba?sub

<b>免费自适应节点b</b>：https://subb.cndyw.ggff.net/subb?sub

<img src="https://sub.cndyw.ggff.net/ys.png">
